package com.boa;

import java.util.HashMap;
import java.util.Map;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;

public class Test123 implements Callable{

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		MuleMessage message=eventContext.getMessage();
		Map<String, String> queryParams = message.getInboundProperty("http.query.params");
		String data = queryParams.get("data");
		String[] elements=data.split(";");
		Map<String, String> employee=new HashMap<String,String>();
		employee.put("id", elements[0]);
		employee.put("name", elements[1]);
		employee.put("salary", elements[2]);
		employee.put("enabled", elements[3]);
		return employee;
	}
	
}
