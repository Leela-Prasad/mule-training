package com.boa;

import java.util.HashMap;
import java.util.Map;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;

public class EmployeeDataProcessor implements Callable{

	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		
		MuleMessage message=eventContext.getMessage();
		
		Map<String, String> queryParams=message.getInboundProperty("http.query.params");
		
		String data=queryParams.get("data");
		
		HashMap<String, String> employee=processData(data,88);
		
		message.setPayload(employee);
		
		message.setSessionProperty("employee", employee);
		message.setOutboundProperty("employee", employee);
		message.setInvocationProperty("employee", employee);
		
		
		
		return message;
	}
	
	public EmployeeDataProcessor() {
		System.out.println("EmployeeDataProcessor.EmployeeDataProcessor()");
	}
	
	public HashMap<String, String> processData(String data,Integer age){
		
		
		System.out.println("EmployeeDataProcessor.processData()");
		
		String[] elements=data.split(";");
		
		HashMap<String, String> employee=new HashMap<String,String>();
		
		employee.put("id", elements[0]);
		employee.put("name", elements[1]);
		employee.put("salary", elements[2]);
		employee.put("enabled", elements[3]);
		employee.put("age", age+"");
		
		
		return employee;
	}
	
	
	public HashMap<String, String> processDataZZ(String data){
		
		
		System.out.println("EmployeeDataProcessor.processData()");
		
		String[] elements=data.split(";");
		
		HashMap<String, String> employee=new HashMap<String,String>();
		
		employee.put("id", elements[0]);
		employee.put("name", elements[1]);
		employee.put("salary", elements[2]);
		employee.put("enabled", elements[3]);
		
		return employee;
	}
	
}